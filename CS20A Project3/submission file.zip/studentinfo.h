#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

namespace StudentInfo {
	std::string name() { return "Noboru Tokimi"; } //Add your name, no special characters
	std::string id() { return "1735354"; } //Add your id, no special characters
};

#endif